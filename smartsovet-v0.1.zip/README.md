﻿# СмартСовет — архивный срез
Запуск: npm i && npm run dev
Данные: localStorage (vg_votings, vg_votes); сиды через seedIfEmpty().
